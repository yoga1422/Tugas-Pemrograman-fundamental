import java.util.Scanner;

public class Main {
  public static void main(String[]  args) {
    Scanner input = new Scanner(System.in);
    int angka = input.nextInt();
    int[] nilai = new int[angka];
    for (int i = 0; i < angka; i++) {
      System.out.print("");
      nilai[i] = input.nextInt();
    }
    for (int i = angka - 1; i >= 0; i--) {
      System.out.print(nilai[i] + " ");
    }
  }
}