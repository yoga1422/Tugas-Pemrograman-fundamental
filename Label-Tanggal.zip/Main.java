import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        String[] bulan = {
                "Januari",
                "Februari",
                "Maret",
                "April",
                "Mei",
                "Juni",
                "Juli",
                "Agustus",
                "September",
                "Oktober",
                "November",
                "Desember",
        };
        int tanggal = input.nextInt();
        int namaBulan = input.nextInt();
        int tahun = input.nextInt(); {
          
        System.out.print(tanggal + bulan[namaBulan - 1] + tahun);
    }

    }
}